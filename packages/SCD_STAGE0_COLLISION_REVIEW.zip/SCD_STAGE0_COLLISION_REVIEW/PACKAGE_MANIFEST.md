# PACKAGE_MANIFEST — SCD_STAGE0_COLLISION_REVIEW

- built (UTC): 2026-10-03T05:34:47Z
- files: 34

```
./00_README.md
./01_COLLISION_DECISION.md
./02_CLOSEST_WORK_MATRIX.md
./03_SCD_FORMALIZATION.md
./04_COMMIT_GATE_DESIGN_SPACE.md
./05_RISK_REGISTER.md
./AGENT.md
./HAVEDO.md
./PACKAGE_MANIFEST.md
./SHA256SUMS.txt
./TODO.md
./audits/main_agent_source_reads.md
./audits/subagent_concept_sweep.txt
./audits/subagent_named_mad_papers.txt
./audits/subagent_rollback_followers.txt
./docs/00_README.md
./docs/01_COLLISION_DECISION.md
./docs/02_CLOSEST_WORK_MATRIX.md
./docs/03_SCD_FORMALIZATION.md
./docs/04_COMMIT_GATE_DESIGN_SPACE.md
./docs/05_RISK_REGISTER.md
./git_log.txt
./memory/MEMORY.md
./memory/project-origin.md
./repo_structure.md
./sources/comed_2609.26913_abs.html
./sources/debate_or_vote_2508.17536_abs.html
./sources/lmad_2608.01463_abs.html
./sources/reagent_2503.06951_abs.html
./sources/revise_2609.00643_abs.html
./sources/thought_rollback_2412.19707_abs.html
./stage0/COLLISION_ALERT.md
./stage0/LITERATURE_AUDIT.md
./stage0/PRELIMINARY_PREREGISTRATION.md
```
